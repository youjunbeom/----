# -*- coding: utf-8 -*-
"""
응력 계산 프로그램 (Stress Calculator)
------------------------------------
재료역학의 기본 응력 계산을 수행하는 프로그램.

기본 단위계: 힘 [N], 길이 [mm], 응력 [MPa = N/mm^2]
  - 모멘트/토크는 [N*mm] 로 입력한다. (N*m 값이면 1000을 곱할 것)

모듈로 import 해서 함수만 사용할 수도 있고,
직접 실행하면 대화형 메뉴가 뜬다.
"""

import math
import unicodedata

# ----------------------------------------------------------------------
# 1. 단면 성질 (Section properties)
# ----------------------------------------------------------------------

def rect_section(b, h):
    """직사각형 단면: 폭 b, 높이 h [mm]

    반환: dict(A, I, c, S)
      A : 단면적 [mm^2]
      I : 중립축에 대한 단면2차모멘트 [mm^4]
      c : 중립축에서 최외단까지 거리 [mm]
      S : 단면계수 I/c [mm^3]
    """

    A = b * h
    I = b * h ** 3 / 12.0
    c = h / 2.0
    return {"A": A, "I": I, "c": c, "S": I / c}


def circle_section(d):
    """중실 원형 단면: 지름 d [mm]

    반환: dict(A, I, J, c, S)
      J : 극단면2차모멘트 [mm^4] (비틀림용)
    """
    r = d / 2.0
    A = math.pi * r ** 2
    I = math.pi * d ** 4 / 64.0
    J = math.pi * d ** 4 / 32.0
    return {"A": A, "I": I, "J": J, "c": r, "S": I / r}


def tube_section(do, di):
    """중공 원형(파이프) 단면: 바깥지름 do, 안지름 di [mm]"""
    if di >= do:
        raise ValueError("안지름은 바깥지름보다 작아야 합니다.")
    ro = do / 2.0
    A = math.pi * (do ** 2 - di ** 2) / 4.0
    I = math.pi * (do ** 4 - di ** 4) / 64.0
    J = math.pi * (do ** 4 - di ** 4) / 32.0
    return {"A": A, "I": I, "J": J, "c": ro, "S": I / ro}


def rect_tube_section(b, h, bi, hi):
    """속빈 직사각형(박스) 단면: 바깥 b x h, 안쪽 bi x hi [mm]

    반환: dict(A, I, c, S)
      A = b*h - bi*hi
      I = (b*h^3 - bi*hi^3) / 12
      비틀림용 J 는 폐단면 이론(Bredt)이 따로 필요하므로 제공하지 않는다.
    """
    if bi >= b or hi >= h:
        raise ValueError("안쪽 치수는 바깥 치수보다 작아야 합니다.")
    A = b * h - bi * hi
    I = (b * h ** 3 - bi * hi ** 3) / 12.0
    c = h / 2.0
    return {"A": A, "I": I, "c": c, "S": I / c}


# 직사각형 단면의 비틀림 계수 (Saint-Venant)
#   a = 긴 변, t = 짧은 변,  ratio = a/t
#   tau_max = T / (alpha * a * t^2)   <- 긴 변의 중앙에서 발생
#   phi     = T*L / (beta * a * t^3 * G)
_RECT_TORSION_TABLE = (
    # a/t      alpha    beta
    (1.0,     0.208,   0.1406),
    (1.5,     0.231,   0.1958),
    (2.0,     0.246,   0.2287),
    (2.5,     0.258,   0.2494),
    (3.0,     0.267,   0.2633),
    (4.0,     0.282,   0.2808),
    (5.0,     0.291,   0.2913),
    (6.0,     0.299,   0.2983),
    (10.0,    0.312,   0.3123),
    (1.0e9,   0.333,   0.3333),
)


def rect_torsion_coeff(b, h):
    """직사각형 단면의 비틀림 계수를 선형보간으로 구한다.

    반환: (a, t, alpha, beta)  a=긴 변, t=짧은 변 [mm]
    """
    if b <= 0 or h <= 0:
        raise ValueError("b, h는 0보다 커야 합니다.")
    a = max(b, h)
    t = min(b, h)
    ratio = a / t
    tbl = _RECT_TORSION_TABLE
    for i in range(len(tbl) - 1):
        r0, a0, b0 = tbl[i]
        r1, a1, b1 = tbl[i + 1]
        if ratio <= r1:
            f = (ratio - r0) / (r1 - r0)
            return a, t, a0 + f * (a1 - a0), b0 + f * (b1 - b0)
    return a, t, 0.333, 0.3333


def rect_torsional_stress(T, b, h):
    """직사각형 단면의 최대 비틀림 전단응력 [MPa]

    원형 단면과 달리 J 공식(T*r/J)을 쓸 수 없으므로 계수법을 사용한다.
    """
    a, t, alpha, _ = rect_torsion_coeff(b, h)
    return T / (alpha * a * t ** 2)


def rect_angle_of_twist(T, L, b, h, G):
    """직사각형 단면의 비틀림각 [rad]"""
    if G <= 0:
        raise ValueError("G는 0보다 커야 합니다.")
    a, t, _, beta = rect_torsion_coeff(b, h)
    return T * L / (beta * a * t ** 3 * G)


# ----------------------------------------------------------------------
# 2. 기본 응력
# ----------------------------------------------------------------------

def axial_stress(P, A):
    """축응력(인장/압축)  sigma = P / A

    P : 축하중 [N] (인장 +, 압축 -)
    A : 단면적 [mm^2]
    반환: 응력 [MPa]
    """
    if A <= 0:
        raise ValueError("단면적 A는 0보다 커야 합니다.")
    return P / A


def shear_stress(V, A):
    """평균 전단응력  tau = V / A

    V : 전단력 [N], A : 전단 저항 단면적 [mm^2]
    """
    if A <= 0:
        raise ValueError("단면적 A는 0보다 커야 합니다.")
    return V / A


def bearing_stress(P, d, t):
    """지압응력(핀/볼트)  sigma_b = P / (d * t)

    d : 핀 지름 [mm], t : 판 두께 [mm]
    """
    if d <= 0 or t <= 0:
        raise ValueError("d, t는 0보다 커야 합니다.")
    return P / (d * t)


def bending_stress(M, c, I):
    """굽힘응력  sigma = M * c / I

    M : 굽힘모멘트 [N*mm], c : 중립축에서의 거리 [mm], I : 단면2차모멘트 [mm^4]
    """
    if I <= 0:
        raise ValueError("단면2차모멘트 I는 0보다 커야 합니다.")
    return M * c / I


def torsional_stress(T, r, J):
    """비틀림 전단응력  tau = T * r / J

    T : 토크 [N*mm], r : 중심에서의 거리 [mm], J : 극단면2차모멘트 [mm^4]
    """
    if J <= 0:
        raise ValueError("극단면2차모멘트 J는 0보다 커야 합니다.")
    return T * r / J


def thin_wall_pressure(p, d, t):
    """얇은 벽 원통 압력용기의 응력

    p : 내압 [MPa], d : 내경 [mm], t : 벽 두께 [mm]
    반환: (원주응력 hoop, 축방향응력 longitudinal) [MPa]
    """
    if t <= 0:
        raise ValueError("두께 t는 0보다 커야 합니다.")
    if d / t < 10:
        print("  [주의] d/t < 10 이면 얇은 벽 가정이 부정확합니다.")
    hoop = p * d / (2.0 * t)
    longitudinal = p * d / (4.0 * t)
    return hoop, longitudinal


# ----------------------------------------------------------------------
# 3. 변형 (Deformation) - 후크의 법칙
# ----------------------------------------------------------------------

def strain_from_stress(sigma, E):
    """후크의 법칙  epsilon = sigma / E   (E [MPa])"""
    if E <= 0:
        raise ValueError("탄성계수 E는 0보다 커야 합니다.")
    return sigma / E


def axial_elongation(P, L, A, E):
    """축방향 변형량  delta = P*L / (A*E)  [mm]"""
    if A <= 0 or E <= 0:
        raise ValueError("A, E는 0보다 커야 합니다.")
    return P * L / (A * E)


def angle_of_twist(T, L, J, G):
    """비틀림각  phi = T*L / (J*G)  [rad]  (G [MPa])"""
    if J <= 0 or G <= 0:
        raise ValueError("J, G는 0보다 커야 합니다.")
    return T * L / (J * G)


# ----------------------------------------------------------------------
# 4. 평면응력 - 주응력 / Mohr 원
# ----------------------------------------------------------------------

def principal_stresses(sx, sy, txy):
    """평면응력 상태의 주응력과 최대 전단응력

    sx, sy : 수직응력 [MPa], txy : 전단응력 [MPa]
    반환: dict
      s1, s2   : 주응력 (s1 >= s2) [MPa]
      theta_p  : 주평면 각도 [deg] (반시계 +)
      tau_max  : 면내 최대 전단응력 [MPa]
      theta_s  : 최대 전단면 각도 [deg]
      s_avg    : 평균응력 (Mohr 원의 중심) [MPa]
      R        : Mohr 원의 반지름 [MPa]
    """
    s_avg = (sx + sy) / 2.0
    R = math.sqrt(((sx - sy) / 2.0) ** 2 + txy ** 2)
    s1 = s_avg + R
    s2 = s_avg - R
    # 2*theta_p = atan2(2*txy, sx - sy)
    theta_p = math.degrees(math.atan2(2.0 * txy, sx - sy)) / 2.0
    theta_s = theta_p - 45.0
    return {
        "s1": s1, "s2": s2, "theta_p": theta_p,
        "tau_max": R, "theta_s": theta_s,
        "s_avg": s_avg, "R": R,
    }


def stress_transformation(sx, sy, txy, theta_deg):
    """평면응력 변환: theta 만큼 회전한 좌표계에서의 응력

    반환: (sx', sy', tx'y') [MPa]
    """
    th = math.radians(theta_deg)
    c2 = math.cos(2 * th)
    s2 = math.sin(2 * th)
    avg = (sx + sy) / 2.0
    dif = (sx - sy) / 2.0
    sxp = avg + dif * c2 + txy * s2
    syp = avg - dif * c2 - txy * s2
    txyp = -dif * s2 + txy * c2
    return sxp, syp, txyp


def von_mises_2d(sx, sy, txy):
    """평면응력의 von Mises 등가응력 [MPa]"""
    return math.sqrt(sx ** 2 - sx * sy + sy ** 2 + 3.0 * txy ** 2)


def transverse_shear_max(V, A, shape="rect"):
    """굽힘에 동반되는 최대 횡전단응력 (중립축에서 발생) [MPa]

    직사각형 : tau_max = 1.5 * V/A
    중실 원형 : tau_max = (4/3) * V/A
    중공 원형 : tau_max = 2.0 * V/A  (얇은 관 근사)
    """
    if A <= 0:
        raise ValueError("단면적 A는 0보다 커야 합니다.")
    k = {"rect": 1.5, "circle": 4.0 / 3.0, "tube": 2.0}.get(shape, 1.5)
    return k * V / A


def evaluate_point(sx, sy, txy, sigma_allow=None):
    """한 점의 응력상태를 종합 평가한다.

    principal_stresses 의 결과에 다음을 추가로 담아 반환한다.
      tau_abs_max  : 3차원까지 고려한 절대 최대 전단응력 (s3=0 인 평면응력)
      sigma_vm     : von Mises 등가응력 (연성재료, 전단변형에너지설)
      sigma_tresca : Tresca 등가응력 (최대전단응력설, 보수적)
      n_vm, n_tresca : sigma_allow 를 주면 각 설에 대한 안전율
    """
    r = principal_stresses(sx, sy, txy)
    s1, s2 = r["s1"], r["s2"]
    # 평면응력이므로 제3주응력 s3 = 0 을 포함해서 판단해야 한다.
    r["tau_abs_max"] = max(r["R"], abs(s1) / 2.0, abs(s2) / 2.0)
    r["sigma_vm"] = von_mises_2d(sx, sy, txy)
    r["sigma_tresca"] = max(abs(s1 - s2), abs(s1), abs(s2))
    if sigma_allow:
        r["n_vm"] = sigma_allow / r["sigma_vm"] if r["sigma_vm"] > 1e-12 else float("inf")
        r["n_tresca"] = (sigma_allow / r["sigma_tresca"]
                         if r["sigma_tresca"] > 1e-12 else float("inf"))
    return r


# ----------------------------------------------------------------------
# 5. 안전율
# ----------------------------------------------------------------------

def safety_factor(sigma_ref, sigma_working):
    """안전율  n = 기준(항복/허용)응력 / 작용응력"""
    if abs(sigma_working) < 1e-12:
        raise ValueError("작용응력이 0이라 안전율을 계산할 수 없습니다.")
    return sigma_ref / abs(sigma_working)


# ----------------------------------------------------------------------
# 6. 대화형 인터페이스
# ----------------------------------------------------------------------

def _pad(text, width):
    """한글(전각)은 2칸을 차지하므로 표시 폭 기준으로 왼쪽 정렬한다."""
    w = sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
            for ch in text)
    return text + " " * max(0, width - w)


def _num(prompt, positive=False):
    """숫자 입력 (잘못 입력하면 다시 물어봄)"""
    while True:
        try:
            v = float(input(prompt).strip())
        except ValueError:
            print("  -> 숫자를 입력하세요.")
            continue
        if positive and v <= 0:
            print("  -> 0보다 큰 값을 입력하세요.")
            continue
        return v


def _num_moment(label):
    """모멘트/토크 입력. 내부 단위는 N*mm 이므로 다른 단위는 자동 환산한다."""
    v = _num("  {} = ".format(label))
    u = input("  └ 단위 (1: N*mm [기본], 2: N*m, 3: kgf*m) > ").strip()
    if u == "2":
        v *= 1000.0
        print("     -> {:,.4f} N*mm".format(v))
    elif u == "3":
        v *= 9806.65
        print("     -> {:,.4f} N*mm".format(v))
    return v


def _ask_section(need_J=False):
    """단면 형상을 물어보고 단면 성질 dict를 반환"""
    print("")
    print("  단면 형상 선택")
    print("   1) 직사각형   2) 중실 원형   3) 중공 원형(파이프)   4) 직접 입력")
    k = input("  번호 > ").strip()
    if k == "1":
        b = _num("  폭 b [mm] = ", True)
        h = _num("  높이 h [mm] = ", True)
        sec = rect_section(b, h)
        sec.update(shape="rect", b=b, h=h)
        if need_J:
            print("  [참고] 직사각형은 T*r/J 가 성립하지 않아 계수법(alpha, beta)을 씁니다.")
    elif k == "2":
        d = _num("  지름 d [mm] = ", True)
        sec = circle_section(d)
        sec.update(shape="circle", d=d)
    elif k == "3":
        do = _num("  바깥지름 do [mm] = ", True)
        di = _num("  안지름 di [mm] = ", True)
        sec = tube_section(do, di)
        sec.update(shape="tube", do=do, di=di)
    else:
        sec = {"shape": "custom"}
        sec["A"] = _num("  단면적 A [mm^2] = ", True)
        sec["I"] = _num("  단면2차모멘트 I [mm^4] = ", True)
        sec["c"] = _num("  최외단 거리 c [mm] = ", True)
        sec["S"] = sec["I"] / sec["c"]
        if need_J:
            sec["J"] = _num("  극단면2차모멘트 J [mm^4] = ", True)

    print("")
    print("  [단면 성질]")
    print("   A = {:>16,.3f} mm^2".format(sec["A"]))
    print("   I = {:>16,.3f} mm^4".format(sec["I"]))
    print("   c = {:>16,.3f} mm".format(sec["c"]))
    print("   S = {:>16,.3f} mm^3".format(sec["S"]))
    if "J" in sec:
        print("   J = {:>16,.3f} mm^4".format(sec["J"]))
    return sec


def menu_axial():
    print("")
    print("[1] 원형 봉의 축응력 (인장/압축)")
    P_kN = _num("  축하중 P [kN] (인장 +, 압축 -) = ")
    d = _num("  직경 d [mm] = ", True)
    P = P_kN * 1000.0              # kN -> N
    A = circle_section(d)["A"]     # A = pi*d^2/4
    s = axial_stress(P, A)
    kind = "인장" if s > 0 else ("압축" if s < 0 else "무응력")
    print("")
    print("  응력 sigma = {:.2f} MPa  ({})".format(abs(s), kind))

    if input("  변형량도 계산할까요? (y/n) ").strip().lower() == "y":
        L = _num("  길이 L [mm] = ", True)
        E = _num("  탄성계수 E [MPa] (강 ~ 200000) = ", True)
        delta = axial_elongation(P, L, A, E)
        eps = strain_from_stress(s, E)
        print("  변형률 epsilon = {:.6e}".format(eps))
        print("  변형량 delta   = {:.6f} mm".format(delta))


def menu_shear():
    print("")
    print("[2] 전단응력 / 지압응력")
    print("   1) 평균 전단응력   2) 지압응력   3) 볼트 단전단/복전단")
    k = input("  번호 > ").strip()
    if k == "2":
        P = _num("  하중 P [N] = ")
        d = _num("  핀 지름 d [mm] = ", True)
        t = _num("  판 두께 t [mm] = ", True)
        print("")
        print("  sigma_b = P/(d*t) = {:.4f} MPa".format(bearing_stress(P, d, t)))
    elif k == "3":
        P = _num("  하중 P [N] = ")
        d = _num("  볼트 지름 d [mm] = ", True)
        n = _num("  전단면 수 (단전단 1, 복전단 2) = ", True)
        A = n * math.pi * d ** 2 / 4.0
        print("")
        print("  전단 저항면적 A = {:.4f} mm^2".format(A))
        print("  tau = {:.4f} MPa".format(shear_stress(P, A)))
    else:
        V = _num("  전단력 V [N] = ")
        A = _num("  전단 단면적 A [mm^2] = ", True)
        print("")
        print("  tau = V/A = {:.4f} MPa".format(shear_stress(V, A)))


def menu_bending():
    print("")
    print("[3] 굽힘응력")
    M = _num_moment("굽힘모멘트 M")
    sec = _ask_section()
    s = bending_stress(M, sec["c"], sec["I"])
    print("")
    print("  sigma_max = M*c/I = {:.4f} MPa".format(s))
    print("  (= M/S = {:.4f} MPa, 최외단에 +/- 로 작용)".format(M / sec["S"]))


def menu_torsion():
    print("")
    print("[4] 비틀림 전단응력 (원형 단면)")
    T = _num_moment("토크 T")
    sec = _ask_section(need_J=True)
    is_rect = sec.get("shape") == "rect"

    if is_rect:
        a, t, alpha, beta = rect_torsion_coeff(sec["b"], sec["h"])
        tau = rect_torsional_stress(T, sec["b"], sec["h"])
        print("")
        print("  a/t = {:.3f}  ->  alpha = {:.4f}, beta = {:.4f}".format(a / t, alpha, beta))
        print("  tau_max = T/(alpha*a*t^2) = {:.4f} MPa   (긴 변의 중앙)".format(tau))
    elif "J" in sec:
        tau = torsional_stress(T, sec["c"], sec["J"])
        print("")
        print("  tau_max = T*r/J = {:.4f} MPa".format(tau))
    else:
        print("  J 값이 없어 계산할 수 없습니다.")
        return

    if input("  비틀림각도 계산할까요? (y/n) ").strip().lower() == "y":
        L = _num("  길이 L [mm] = ", True)
        G = _num("  전단탄성계수 G [MPa] (강 ~ 79000) = ", True)
        if is_rect:
            phi = rect_angle_of_twist(T, L, sec["b"], sec["h"], G)
        else:
            phi = angle_of_twist(T, L, sec["J"], G)
        print("  phi = {:.6e} rad = {:.4f} deg".format(phi, math.degrees(phi)))


def menu_pressure():
    print("")
    print("[5] 얇은 벽 압력용기")
    p = _num("  내압 p [MPa] = ")
    d = _num("  내경 d [mm] = ", True)
    t = _num("  벽 두께 t [mm] = ", True)
    hoop, lon = thin_wall_pressure(p, d, t)
    print("")
    print("  원주(후프)응력  sigma_h = p*d/(2t) = {:.4f} MPa".format(hoop))
    print("  축방향응력      sigma_l = p*d/(4t) = {:.4f} MPa".format(lon))


def menu_principal():
    print("")
    print("[6] 평면응력 - 주응력 / Mohr 원")
    sx = _num("  sigma_x  [MPa] = ")
    sy = _num("  sigma_y  [MPa] = ")
    txy = _num("  tau_xy   [MPa] = ")
    r = principal_stresses(sx, sy, txy)
    print("")
    print("  평균응력   sigma_avg = {:>12.4f} MPa   (Mohr 원 중심)".format(r["s_avg"]))
    print("  반지름     R         = {:>12.4f} MPa".format(r["R"]))
    print("  주응력     sigma_1   = {:>12.4f} MPa".format(r["s1"]))
    print("             sigma_2   = {:>12.4f} MPa".format(r["s2"]))
    print("  주평면각   theta_p   = {:>12.4f} deg".format(r["theta_p"]))
    print("  최대전단   tau_max   = {:>12.4f} MPa".format(r["tau_max"]))
    print("  전단면각   theta_s   = {:>12.4f} deg".format(r["theta_s"]))
    e = evaluate_point(sx, sy, txy)
    print("  절대최대전단 tau_abs  = {:>12.4f} MPa  (s3=0 포함)".format(e["tau_abs_max"]))
    print("  von Mises  sigma_vm  = {:>12.4f} MPa  (연성재료 권장)".format(e["sigma_vm"]))
    print("  Tresca     sigma_tr  = {:>12.4f} MPa  (보수적)".format(e["sigma_tresca"]))

    print("")
    if input("  임의 각도로 응력변환 할까요? (y/n) ").strip().lower() == "y":
        th = _num("  회전각 theta [deg] (반시계 +) = ")
        a, b, c = stress_transformation(sx, sy, txy, th)
        print("  sigma_x' = {:>12.4f} MPa".format(a))
        print("  sigma_y' = {:>12.4f} MPa".format(b))
        print("  tau_x'y' = {:>12.4f} MPa".format(c))


def menu_combined():
    print("")
    print("[8] 조합응력 (축력 + 굽힘 + 비틀림 + 횡전단)")
    print("  같은 단면에 여러 하중이 동시에 걸릴 때, 위험점 2곳을 평가합니다.")
    sec = _ask_section(need_J=True)
    shape = sec.get("shape", "custom")

    print("")
    print("  [하중 입력]  걸리지 않는 하중은 0 을 입력하세요.")
    P = _num("  축하중 P [N] (인장 +, 압축 -) = ")
    M = _num_moment("굽힘모멘트 M")
    T = _num_moment("토크 T")
    V = _num("  전단력 V [N] = ")

    # 각 하중이 만드는 성분응력
    s_axial = P / sec["A"]
    s_bend = bending_stress(M, sec["c"], sec["I"]) if M else 0.0
    if T:
        if shape == "rect":
            t_tor = rect_torsional_stress(T, sec["b"], sec["h"])
        elif "J" in sec:
            t_tor = torsional_stress(T, sec["c"], sec["J"])
        else:
            print("  [주의] J 가 없어 비틀림은 무시합니다.")
            t_tor = 0.0
    else:
        t_tor = 0.0
    t_shear = transverse_shear_max(V, sec["A"], shape) if V else 0.0

    print("")
    print("  [성분응력]")
    print("   축응력      P/A      = {:>12.4f} MPa".format(s_axial))
    print("   굽힘응력    M*c/I    = {:>12.4f} MPa".format(s_bend))
    print("   비틀림응력  tau_T    = {:>12.4f} MPa".format(t_tor))
    print("   횡전단응력  tau_V    = {:>12.4f} MPa  (중립축에서 최대)".format(t_shear))

    # 위험점 A : 최외단 - 굽힘응력 최대, 횡전단 = 0
    # 위험점 B : 중립축 - 굽힘응력 = 0, 횡전단 최대
    points = [
        ("A (최외단, 굽힘 인장측)", s_axial + s_bend, t_tor),
        ("B (중립축)", s_axial, t_tor + t_shear),
    ]
    if s_bend:
        points.insert(1, ("A' (최외단, 굽힘 압축측)", s_axial - s_bend, t_tor))

    print("")
    allow = _num("  허용(항복)응력 [MPa] (모르면 0) = ")
    allow = allow if allow > 0 else None

    print("")
    print("  " + "-" * 64)
    print("  {}{:>10s}{:>10s}{:>9s}{:>9s}".format(
        _pad("위험점", 26), "sigma", "tau", "s_vm", "s_tr"))
    print("  " + "-" * 64)
    worst = None
    for name, sn, tau in points:
        e = evaluate_point(sn, 0.0, tau, allow)
        print("  {}{:>10.3f}{:>10.3f}{:>9.3f}{:>9.3f}".format(
            _pad(name, 26), sn, tau, e["sigma_vm"], e["sigma_tresca"]))
        if worst is None or e["sigma_vm"] > worst[1]["sigma_vm"]:
            worst = (name, e, sn, tau)
    print("  " + "-" * 64)

    name, e, sn, tau = worst
    print("")
    print("  [지배 위험점] {}".format(name))
    print("   주응력  sigma_1 = {:>12.4f} MPa".format(e["s1"]))
    print("           sigma_2 = {:>12.4f} MPa".format(e["s2"]))
    print("   절대최대전단    = {:>12.4f} MPa".format(e["tau_abs_max"]))
    print("   von Mises       = {:>12.4f} MPa".format(e["sigma_vm"]))
    print("   Tresca          = {:>12.4f} MPa".format(e["sigma_tresca"]))
    if allow:
        print("")
        print("   안전율 n (von Mises) = {:.3f}".format(e["n_vm"]))
        print("   안전율 n (Tresca)    = {:.3f}".format(e["n_tresca"]))
        print("   판정: {}".format("안전" if e["n_vm"] >= 1.0 else "위험 - 단면을 키우세요"))


def menu_safety():
    print("")
    print("[7] 안전율 / 허용응력")
    sy = _num("  항복(또는 허용) 응력 [MPa] = ", True)
    sw = _num("  작용(계산) 응력 [MPa] = ")
    n = safety_factor(sy, sw)
    print("")
    print("  안전율 n = {:.4f}".format(n))
    print("  판정: {}".format("안전 (n >= 1)" if n >= 1.0 else "위험 (n < 1)"))


MENU = """
==================================================
             응력 계산 프로그램
   단위: 힘 [N], 길이 [mm], 응력 [MPa=N/mm^2]
         모멘트/토크 [N*mm]
==================================================
  1. 원형 봉의 축응력 (입력: P [kN], d [mm])
  2. 전단응력 / 지압응력
  3. 굽힘응력
  4. 비틀림 전단응력 + 비틀림각
  5. 얇은 벽 압력용기
  6. 평면응력 (주응력 / Mohr 원 / von Mises)
  7. 안전율
  8. 조합응력 (축력+굽힘+비틀림 -> 위험점 판정)
  9. 단면 성질만 계산
  0. 종료
--------------------------------------------------"""


def main():
    actions = {
        "1": menu_axial,
        "2": menu_shear,
        "3": menu_bending,
        "4": menu_torsion,
        "5": menu_pressure,
        "6": menu_principal,
        "7": menu_safety,
        "8": menu_combined,
        "9": lambda: _ask_section(need_J=True),
    }
    while True:
        print(MENU)
        sel = input("  선택 > ").strip()
        if sel == "0":
            print("")
            print("  프로그램을 종료합니다.")
            break
        if sel not in actions:
            print("  -> 0~9 중에서 선택하세요.")
            continue
        try:
            actions[sel]()
        except ValueError as e:
            print("  [입력 오류] {}".format(e))
        input("\n  (엔터를 누르면 메뉴로 돌아갑니다) ")


# ----------------------------------------------------------------------
# 7. 자체 검증  (python stress_calculator.py --test)
# ----------------------------------------------------------------------

def self_test():
    """손계산으로 확인 가능한 값과 비교한다. 실패 개수를 반환."""
    fails = []

    def chk(name, got, exp, tol=1e-6):
        ok = abs(got - exp) <= tol * max(1.0, abs(exp))
        print("  {} {} 계산={:>14.6g}  기대={:>14.6g}".format(
            "OK  " if ok else "FAIL", _pad(name, 32), got, exp))
        if not ok:
            fails.append(name)

    print("")
    print("================ 자체 검증 ================")

    # --- 단면 성질 ---
    r = rect_section(50, 100)
    chk("직사각형 A = b*h", r["A"], 5000)
    chk("직사각형 I = b*h^3/12", r["I"], 50 * 100 ** 3 / 12)
    chk("직사각형 S = b*h^2/6", r["S"], 50 * 100 ** 2 / 6)
    c = circle_section(50)
    chk("원형 A = pi*d^2/4", c["A"], math.pi * 50 ** 2 / 4)
    chk("원형 J = 2*I", c["J"], 2 * c["I"])
    tu = tube_section(50, 40)
    chk("파이프 A", tu["A"], math.pi * (50 ** 2 - 40 ** 2) / 4)
    bx = rect_tube_section(100, 200, 80, 180)
    chk("속빈 직사각형 A", bx["A"], 100 * 200 - 80 * 180)
    chk("속빈 직사각형 I", bx["I"], (100 * 200 ** 3 - 80 * 180 ** 3) / 12)

    # --- 기본 응력 ---
    chk("축응력 10kN / 100mm^2", axial_stress(10000, 100), 100)
    chk("굽힘 M*c/I = M/S", bending_stress(10e6, r["c"], r["I"]), 10e6 / r["S"])
    chk("비틀림 = 16T/(pi*d^3)", torsional_stress(1e6, c["c"], c["J"]),
        16 * 1e6 / (math.pi * 50 ** 3))
    chk("지압 P/(d*t)", bearing_stress(10000, 20, 10), 50)
    h, l = thin_wall_pressure(2, 1000, 10)
    chk("후프응력 p*d/(2t)", h, 100)
    chk("축방향응력 p*d/(4t)", l, 50)

    # --- 직사각형 비틀림 (정사각형이면 alpha=0.208, beta=0.1406) ---
    a, t, alpha, beta = rect_torsion_coeff(30, 30)
    chk("정사각형 alpha", alpha, 0.208)
    chk("정사각형 beta", beta, 0.1406)
    chk("직사각형 T/(alpha*a*t^2)", rect_torsional_stress(1e5, 30, 30),
        1e5 / (0.208 * 30 * 30 ** 2))

    # --- 변형 ---
    chk("신장 P*L/(A*E)", axial_elongation(10000, 1000, 100, 200000), 0.5)
    chk("변형률 sigma/E", strain_from_stress(100, 200000), 5e-4)

    # --- 평면응력 (80, -40, 25 -> 85 / -45) ---
    pr = principal_stresses(80, -40, 25)
    chk("주응력 sigma_1", pr["s1"], 85)
    chk("주응력 sigma_2", pr["s2"], -45)
    chk("면내 최대전단", pr["tau_max"], 65)
    chk("주평면에서 tau = 0", stress_transformation(80, -40, 25, pr["theta_p"])[2],
        0, 1e-9)
    chk("불변량 sx+sy 보존", sum(stress_transformation(80, -40, 25, 37.0)[:2]), 40)

    # --- 파손이론 ---
    chk("von Mises 단축인장", von_mises_2d(250, 0, 0), 250)
    chk("von Mises 순수전단", von_mises_2d(0, 0, 100), math.sqrt(3) * 100)
    chk("Tresca 순수전단", evaluate_point(0, 0, 100)["sigma_tresca"], 200)
    chk("단축인장 절대최대전단", evaluate_point(100, 0, 0)["tau_abs_max"], 50)
    chk("안전율 250 / 100", safety_factor(250, -100), 2.5)

    # --- 횡전단 ---
    chk("직사각형 1.5*V/A", transverse_shear_max(3000, 5000, "rect"), 0.9)
    chk("원형 (4/3)*V/A", transverse_shear_max(3000, 5000, "circle"), 0.8)

    print("===========================================")
    if fails:
        print("  {}개 실패: {}".format(len(fails), ", ".join(fails)))
    else:
        print("  전체 통과.")
    print("")
    return len(fails)


if __name__ == "__main__":
    import sys

    if "--test" in sys.argv:
        sys.exit(1 if self_test() else 0)
    try:
        main()
    except (EOFError, KeyboardInterrupt):
        print("\n프로그램을 종료합니다.")
