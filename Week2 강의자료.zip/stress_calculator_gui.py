# -*- coding: utf-8 -*-
"""
Stress calculator (GUI)
-----------------------
stress_calculator.py 의 계산 함수를 그대로 사용하는 tkinter 화면.

내부 기준 단위: 힘 [N], 길이 [mm], 모멘트 [N*mm], 응력/압력 [MPa]
화면에서는 드롭다운으로 고른 단위를 기준 단위로 환산해서 계산한다.

실행: python stress_calculator_gui.py
"""

import tkinter as tk
from tkinter import ttk

import stress_calculator as sc


# ----------------------------------------------------------------------
# 화면 설정
# ----------------------------------------------------------------------

WHITE = "white"
FONT_BASE = ("Malgun Gothic", 9)
FONT_RESULT = ("Consolas", 12, "bold")
COLOR_TENSION = "#0050C8"      # 인장
COLOR_COMPRESS = "#C00000"     # 압축
COLOR_NORMAL = "black"
COLOR_ERROR = "#C00000"


# ----------------------------------------------------------------------
# 단위 정의
#   factor = 그 단위 1개가 기준 단위로 몇 개인가
#   기준값 = 입력값 * factor,   화면표시값 = 기준값 / factor
# ----------------------------------------------------------------------

UNITS = {
    "force":    [("N", 1.0), ("kN", 1000.0), ("kgf", 9.80665)],
    "length":   [("mm", 1.0), ("cm", 10.0), ("m", 1000.0)],
    "moment":   [("N*mm", 1.0), ("N*m", 1000.0), ("kgf*m", 9806.65)],
    "pressure": [("MPa", 1.0), ("bar", 0.1), ("kgf/cm^2", 0.0980665)],
    "stress":   [("MPa", 1.0), ("GPa", 1000.0), ("kgf/cm^2", 0.0980665)],
}


def unit_names(kind):
    return [name for name, _ in UNITS[kind]]


def unit_factor(kind, name):
    for n, f in UNITS[kind]:
        if n == name:
            return f
    return 1.0


# ----------------------------------------------------------------------
# 단면 형상 정의 : 형상이름 -> [(키, 라벨), ...]
# ----------------------------------------------------------------------

SHAPES = {
    "원형": [("d", "지름 d")],
    "직사각형": [("b", "폭 b"), ("h", "높이 h")],
    "속빈 원형": [("do", "바깥지름 do"), ("di", "안지름 di")],
    "속빈 직사각형": [("b", "바깥 폭 b"), ("h", "바깥 높이 h"),
                 ("bi", "안쪽 폭 bi"), ("hi", "안쪽 높이 hi")],
}
SHAPE_NAMES = list(SHAPES.keys())


def section_of(shape, v):
    """형상 이름과 치수 dict 로부터 단면 성질을 구한다."""
    if shape == "원형":
        return sc.circle_section(v["d"])
    if shape == "직사각형":
        return sc.rect_section(v["b"], v["h"])
    if shape == "속빈 원형":
        return sc.tube_section(v["do"], v["di"])
    return sc.rect_tube_section(v["b"], v["h"], v["bi"], v["hi"])


# ----------------------------------------------------------------------
# 계산 종류 정의
#   fields : (키, 라벨, 단위종류 또는 None, 0보다 커야 하는가)
# ----------------------------------------------------------------------

CALCS = [
    "1. 축응력",
    "2. 전단응력 (평균)",
    "3. 지압응력",
    "4. 볼트 전단",
    "5. 굽힘응력",
    "6. 압력용기 (얇은 벽)",
    "7. 평면응력",
    "8. 단면 성질",
]

SPEC = {
    "1. 축응력": {
        "shape": True,
        "fields": [("P", "축하중 P (인장 +, 압축 -)", "force", False)],
    },
    "2. 전단응력 (평균)": {
        "shape": True,
        "fields": [("V", "전단력 V", "force", False)],
    },
    "3. 지압응력": {
        "shape": False,
        "fields": [("P", "하중 P", "force", False),
                   ("d", "핀 지름 d", "length", True),
                   ("t", "판 두께 t", "length", True)],
    },
    "4. 볼트 전단": {
        "shape": False,
        "fields": [("P", "하중 P", "force", False),
                   ("d", "볼트 지름 d", "length", True),
                   ("n", "전단면 수 (단전단 1, 복전단 2)", None, True)],
    },
    "5. 굽힘응력": {
        "shape": True,
        "fields": [("M", "굽힘모멘트 M", "moment", False)],
    },
    "6. 압력용기 (얇은 벽)": {
        "shape": False,
        "fields": [("p", "내압 p", "pressure", False),
                   ("d", "내경 d", "length", True),
                   ("t", "벽 두께 t", "length", True)],
    },
    "7. 평면응력": {
        "shape": False,
        "fields": [("sx", "sigma_x", "stress", False),
                   ("sy", "sigma_y", "stress", False),
                   ("txy", "tau_xy", "stress", False)],
    },
    "8. 단면 성질": {
        "shape": True,
        "fields": [],
    },
}

# 결과가 응력이 아니라서 출력 단위 드롭다운을 쓰지 않는 계산
NO_STRESS_OUTPUT = ("8. 단면 성질",)


class InputError(Exception):
    """입력 검증 실패"""


def fmt(x):
    """항상 지수표기, 유효숫자 3자리"""
    return "{:.2e}".format(x)


# ----------------------------------------------------------------------
# 본체
# ----------------------------------------------------------------------

class StressApp:

    def __init__(self, root):
        self.root = root
        root.title("Stress calculator")
        root.configure(bg=WHITE)
        root.geometry("560x660")
        root.resizable(False, False)

        self.rows = {}          # 입력칸 정보
        self.shape_combo = None
        # 화면을 다시 그려도 고른 형상이 유지되도록 여기서 한 번만 만든다
        self.shape_var = tk.StringVar(value=SHAPE_NAMES[0])
        # CE 는 "마지막으로 편집하던 칸"을 지운다.
        # 버튼을 클릭하면 포커스가 버튼으로 옮겨가므로 focus_get() 은 쓸 수 없다.
        self.last_key = None

        main = tk.Frame(root, bg=WHITE, padx=16, pady=12)
        main.pack(fill="both", expand=True)

        # --- 계산 종류 ---
        top = tk.Frame(main, bg=WHITE)
        top.pack(fill="x")
        tk.Label(top, text="계산 종류", bg=WHITE, font=FONT_BASE,
                 width=14, anchor="w").pack(side="left")
        self.calc_var = tk.StringVar(value=CALCS[0])
        cb = ttk.Combobox(top, textvariable=self.calc_var, values=CALCS,
                          state="readonly", width=34, font=FONT_BASE)
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self.build_inputs())

        tk.Frame(main, bg="#DDDDDD", height=1).pack(fill="x", pady=8)

        # --- 입력 영역 (고정 높이) ---
        self.holder = tk.Frame(main, bg=WHITE, height=240, width=520)
        self.holder.pack(fill="x")
        self.holder.pack_propagate(False)

        # --- 버튼 ---
        btns = tk.Frame(main, bg=WHITE)
        btns.pack(fill="x", pady=(4, 6))
        tk.Button(btns, text="계산", width=10, bg=WHITE, font=FONT_BASE,
                  command=self.calculate).pack(side="left")
        tk.Button(btns, text="CE", width=7, bg=WHITE, font=FONT_BASE,
                  command=self.clear_entry).pack(side="left", padx=6)
        tk.Button(btns, text="C", width=7, bg=WHITE, font=FONT_BASE,
                  command=self.clear_all).pack(side="left")

        # --- 출력 단위 ---
        out = tk.Frame(main, bg=WHITE)
        out.pack(fill="x")
        tk.Label(out, text="출력 응력 단위", bg=WHITE, font=FONT_BASE,
                 width=14, anchor="w").pack(side="left")
        self.out_var = tk.StringVar(value="MPa")
        self.out_combo = ttk.Combobox(out, textvariable=self.out_var,
                                      values=unit_names("stress"),
                                      state="readonly", width=10,
                                      font=FONT_BASE)
        self.out_combo.pack(side="left")
        self.out_combo.bind("<<ComboboxSelected>>", lambda e: self.calculate())

        # --- 오류 표시 ---
        self.err_var = tk.StringVar(value="")
        tk.Label(main, textvariable=self.err_var, bg=WHITE, fg=COLOR_ERROR,
                 font=FONT_BASE, anchor="w").pack(fill="x", pady=(8, 2))

        # --- 결과 ---
        res_box = tk.Frame(main, bg=WHITE, height=230)
        res_box.pack(fill="both", expand=True)
        res_box.pack_propagate(False)
        self.res_var = tk.StringVar(value="")
        self.res_label = tk.Label(res_box, textvariable=self.res_var, bg=WHITE,
                                  fg=COLOR_NORMAL, font=FONT_RESULT,
                                  justify="left", anchor="nw")
        self.res_label.pack(fill="both", expand=True)

        # --- 단축키 ---
        root.bind("<Return>", lambda e: self.calculate())
        root.bind("<KP_Enter>", lambda e: self.calculate())
        root.bind("<Escape>", lambda e: self.clear_all())

        self.build_inputs()

    # ------------------------------------------------------------------
    # 입력 화면 구성
    # ------------------------------------------------------------------

    def build_inputs(self):
        for w in self.holder.winfo_children():
            w.destroy()
        self.rows = {}
        self.shape_combo = None
        self.err_var.set("")
        self.res_var.set("")

        spec = SPEC[self.calc_var.get()]

        if spec["shape"]:
            line = tk.Frame(self.holder, bg=WHITE)
            line.pack(fill="x", pady=3)
            tk.Label(line, text="단면 형상", bg=WHITE, font=FONT_BASE,
                     width=22, anchor="w").pack(side="left")
            self.shape_combo = ttk.Combobox(line, textvariable=self.shape_var,
                                            values=SHAPE_NAMES, state="readonly",
                                            width=16, font=FONT_BASE)
            self.shape_combo.pack(side="left")
            self.shape_combo.bind("<<ComboboxSelected>>",
                                  lambda e: self.build_inputs())
            for key, label in SHAPES[self.shape_var.get()]:
                self.add_row(key, label, "length", True)

        for key, label, kind, positive in spec["fields"]:
            self.add_row(key, label, kind, positive)

        # 출력 단위 드롭다운은 응력 결과일 때만 사용
        state = "disabled" if self.calc_var.get() in NO_STRESS_OUTPUT else "readonly"
        self.out_combo.configure(state=state)

        # 첫 칸에 커서를 둔다 (CE 의 기본 대상이 된다)
        self.last_key = None
        for key in self.rows:
            self.rows[key]["entry"].focus_set()
            self.last_key = key
            break

    def add_row(self, key, label, kind, positive):
        line = tk.Frame(self.holder, bg=WHITE)
        line.pack(fill="x", pady=3)
        tk.Label(line, text=label, bg=WHITE, font=FONT_BASE,
                 width=22, anchor="w").pack(side="left")
        ent = tk.Entry(line, width=16, bg=WHITE, font=FONT_BASE,
                       relief="solid", bd=1)
        ent.pack(side="left")
        ent.bind("<FocusIn>", lambda e, k=key: self.remember(k))
        combo = None
        if kind is not None:
            combo = ttk.Combobox(line, values=unit_names(kind), state="readonly",
                                 width=9, font=FONT_BASE)
            combo.set(unit_names(kind)[0])
            combo.pack(side="left", padx=6)
        self.rows[key] = {"entry": ent, "combo": combo, "kind": kind,
                          "label": label, "positive": positive}

    # ------------------------------------------------------------------
    # 입력 읽기 / 검증
    # ------------------------------------------------------------------

    def read(self, key):
        r = self.rows[key]
        try:
            v = float(r["entry"].get().strip())
        except ValueError:
            raise InputError("[{}] 숫자를 입력하세요.".format(r["label"]))
        if r["positive"] and v <= 0:
            raise InputError("[{}] 0보다 큰 값을 입력하세요.".format(r["label"]))
        if r["combo"] is not None:
            v *= unit_factor(r["kind"], r["combo"].get())
        return v

    def read_shape(self):
        shape = self.shape_var.get()
        dims = {}
        for key, _ in SHAPES[shape]:
            dims[key] = self.read(key)
        return shape, section_of(shape, dims)

    # ------------------------------------------------------------------
    # 버튼 동작
    # ------------------------------------------------------------------

    def remember(self, key):
        self.last_key = key

    def clear_entry(self):
        """CE : 마지막으로 편집하던 칸 하나만 지운다."""
        if self.last_key in self.rows:
            ent = self.rows[self.last_key]["entry"]
            ent.delete(0, "end")
            ent.focus_set()

    def clear_all(self):
        for r in self.rows.values():
            r["entry"].delete(0, "end")
        self.err_var.set("")
        self.res_var.set("")
        self.res_label.configure(fg=COLOR_NORMAL)

    # ------------------------------------------------------------------
    # 계산
    # ------------------------------------------------------------------

    def calculate(self):
        try:
            text, color = self.compute()
        except InputError as e:
            self.err_var.set(str(e))
            self.res_var.set("")
            self.res_label.configure(fg=COLOR_NORMAL)
            return
        except ValueError as e:
            self.err_var.set(str(e))
            self.res_var.set("")
            self.res_label.configure(fg=COLOR_NORMAL)
            return
        self.err_var.set("")
        self.res_var.set(text)
        self.res_label.configure(fg=color)

    def compute(self):
        """계산 결과 문자열과 글자색을 돌려준다."""
        calc = self.calc_var.get()
        u = self.out_var.get()
        uf = unit_factor("stress", u)

        def S(mpa):
            """MPa 값을 선택한 출력 단위로 바꿔 문자열로"""
            return "{} {}".format(fmt(mpa / uf), u)

        if calc == "1. 축응력":
            _, sec = self.read_shape()
            P = self.read("P")
            s = sc.axial_stress(P, sec["A"])
            if s > 0:
                kind, color = "인장", COLOR_TENSION
            elif s < 0:
                kind, color = "압축", COLOR_COMPRESS
            else:
                kind, color = "무응력", COLOR_NORMAL
            return "sigma = {}  ({})".format(S(s), kind), color

        if calc == "2. 전단응력 (평균)":
            _, sec = self.read_shape()
            V = self.read("V")
            return "tau = {}".format(S(sc.shear_stress(V, sec["A"]))), COLOR_NORMAL

        if calc == "3. 지압응력":
            P = self.read("P")
            d = self.read("d")
            t = self.read("t")
            return "sigma_b = {}".format(S(sc.bearing_stress(P, d, t))), COLOR_NORMAL

        if calc == "4. 볼트 전단":
            P = self.read("P")
            d = self.read("d")
            n = self.read("n")
            A = n * 3.141592653589793 * d ** 2 / 4.0
            lines = [
                "A   = {} mm^2".format(fmt(A)),
                "tau = {}".format(S(sc.shear_stress(P, A))),
            ]
            return "\n".join(lines), COLOR_NORMAL

        if calc == "5. 굽힘응력":
            _, sec = self.read_shape()
            M = self.read("M")
            s = sc.bending_stress(M, sec["c"], sec["I"])
            lines = [
                "sigma_max = {}".format(S(s)),
                "(최외단에 +/- 로 작용)",
            ]
            return "\n".join(lines), COLOR_NORMAL

        if calc == "6. 압력용기 (얇은 벽)":
            p = self.read("p")
            d = self.read("d")
            t = self.read("t")
            hoop, lon = sc.thin_wall_pressure(p, d, t)
            lines = [
                "sigma_h (원주) = {}".format(S(hoop)),
                "sigma_l (축방향) = {}".format(S(lon)),
            ]
            return "\n".join(lines), COLOR_NORMAL

        if calc == "7. 평면응력":
            sx = self.read("sx")
            sy = self.read("sy")
            txy = self.read("txy")
            r = sc.principal_stresses(sx, sy, txy)
            e = sc.evaluate_point(sx, sy, txy)
            lines = [
                "sigma_avg = {}".format(S(r["s_avg"])),
                "R         = {}".format(S(r["R"])),
                "sigma_1   = {}".format(S(r["s1"])),
                "sigma_2   = {}".format(S(r["s2"])),
                "theta_p   = {} deg".format(fmt(r["theta_p"])),
                "tau_max   = {}".format(S(r["tau_max"])),
                "theta_s   = {} deg".format(fmt(r["theta_s"])),
                "tau_abs   = {}".format(S(e["tau_abs_max"])),
                "sigma_vm  = {}".format(S(e["sigma_vm"])),
                "sigma_tr  = {}".format(S(e["sigma_tresca"])),
            ]
            return "\n".join(lines), COLOR_NORMAL

        # 8. 단면 성질
        _, sec = self.read_shape()
        lines = [
            "A = {} mm^2".format(fmt(sec["A"])),
            "I = {} mm^4".format(fmt(sec["I"])),
            "c = {} mm".format(fmt(sec["c"])),
            "S = {} mm^3".format(fmt(sec["S"])),
        ]
        return "\n".join(lines), COLOR_NORMAL


def main():
    root = tk.Tk()
    StressApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
